#ifndef TGC_H
#define TGC_H

#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <setjmp.h>

enum {
  TGC_MARK = 0x01,
  TGC_ROOT = 0x02,
  TGC_LEAF = 0x04
};

typedef struct {
  void *ptr;
  int flags;
  size_t size, hash;
  void (*dtor)(void*);
} cgc_ptr_t;

typedef struct {
  void *bottom;
  int paused;
  uintptr_t minptr, maxptr;
  cgc_ptr_t *items, *frees;
  double loadfactor, sweepfactor;
  size_t nitems, nslots, mitems, nfrees;
} cgc_t;

void cgc_start(cgc_t *gc, void *stk);
void cgc_stop(cgc_t *gc);
void cgc_pause(cgc_t *gc);
void cgc_resume(cgc_t *gc);
void cgc_run(cgc_t *gc);

void *cgc_alloc(cgc_t *gc, size_t size);
void *cgc_calloc(cgc_t *gc, size_t num, size_t size);
void *cgc_realloc(cgc_t *gc, void *ptr, size_t size);
void cgc_free(cgc_t *gc, void *ptr);

void *cgc_alloc_opt(cgc_t *gc, size_t size, int flags, void(*dtor)(void*));
void *cgc_calloc_opt(cgc_t *gc, size_t num, size_t size, int flags, void(*dtor)(void*));

void cgc_set_dtor(cgc_t *gc, void *ptr, void(*dtor)(void*));
void cgc_set_flags(cgc_t *gc, void *ptr, int flags);
int cgc_get_flags(cgc_t *gc, void *ptr);
void(*cgc_get_dtor(cgc_t *gc, void *ptr))(void*);
size_t cgc_get_size(cgc_t *gc, void *ptr);

#endif
