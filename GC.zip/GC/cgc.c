#include "cgc.h"

static size_t cgc_hash(void *ptr) {
  return ((uintptr_t)ptr) >> 3;
}

static size_t cgc_probe(cgc_t* gc, size_t i, size_t h) {
  long v = i - (h-1);
  if (v < 0) { v = gc->nslots + v; }
  return v;
}

static cgc_ptr_t *cgc_get_ptr(cgc_t *gc, void *ptr) {
  size_t i, j, h;
  i = cgc_hash(ptr) % gc->nslots; j = 0;
  while (1) {
    h = gc->items[i].hash;
    if (h == 0 || j > cgc_probe(gc, i, h)) { return NULL; }
    if (gc->items[i].ptr == ptr) { return &gc->items[i]; }
    i = (i+1) % gc->nslots; j++;
  }
  return NULL;
}

static void cgc_add_ptr(
  cgc_t *gc, void *ptr, size_t size, 
  int flags, void(*dtor)(void*)) {

  cgc_ptr_t item, tmp;
  size_t h, p, i, j;

  i = cgc_hash(ptr) % gc->nslots; j = 0;
  
  item.ptr = ptr;
  item.flags = flags;
  item.size = size;
  item.hash = i+1;
  item.dtor = dtor;
  
  while (1) {
    h = gc->items[i].hash;
    if (h == 0) { gc->items[i] = item; return; }
    if (gc->items[i].ptr == item.ptr) { return; }
    p = cgc_probe(gc, i, h);
    if (j >= p) {
      tmp = gc->items[i];
      gc->items[i] = item;
      item = tmp;
      j = p;
    }
    i = (i+1) % gc->nslots; j++;
  }
  
}

static void cgc_rem_ptr(cgc_t *gc, void *ptr) {

  size_t i, j, h, nj, nh;

  if (gc->nitems == 0) { return; }
  
  for (i = 0; i < gc->nfrees; i++) {
    if (gc->frees[i].ptr == ptr) { gc->frees[i].ptr = NULL; }
  }
  
  i = cgc_hash(ptr) % gc->nslots; j = 0;
  
  while (1) {
    h = gc->items[i].hash;
    if (h == 0 || j > cgc_probe(gc, i, h)) { return; }
    if (gc->items[i].ptr == ptr) {
      memset(&gc->items[i], 0, sizeof(cgc_ptr_t));
      j = i;
      while (1) { 
        nj = (j+1) % gc->nslots;
        nh = gc->items[nj].hash;
        if (nh != 0 && cgc_probe(gc, nj, nh) > 0) {
          memcpy(&gc->items[ j], &gc->items[nj], sizeof(cgc_ptr_t));
          memset(&gc->items[nj],              0, sizeof(cgc_ptr_t));
          j = nj;
        } else {
          break;
        }  
      }
      gc->nitems--;
      return;
    }
    i = (i+1) % gc->nslots; j++;
  }
  
}


enum {
  TGC_PRIMES_COUNT = 24
};

static const size_t cgc_primes[TGC_PRIMES_COUNT] = {
  0,       1,       5,       11,
  23,      53,      101,     197,
  389,     683,     1259,    2417,
  4733,    9371,    18617,   37097,
  74093,   148073,  296099,  592019,
  1100009, 2200013, 4400021, 8800019
};

static size_t cgc_ideal_size(cgc_t* gc, size_t size) {
  size_t i, last;
  size = (size_t)((double)(size+1) / gc->loadfactor);
  for (i = 0; i < TGC_PRIMES_COUNT; i++) {
    if (cgc_primes[i] >= size) { return cgc_primes[i]; }
  }
  last = cgc_primes[TGC_PRIMES_COUNT-1];
  for (i = 0;; i++) {
    if (last * i >= size) { return last * i; }
  }
  return 0;
}

static int cgc_rehash(cgc_t* gc, size_t new_size) {

  size_t i;
  cgc_ptr_t *old_items = gc->items;
  size_t old_size = gc->nslots;
  
  gc->nslots = new_size;
  gc->items = calloc(gc->nslots, sizeof(cgc_ptr_t));
  
  if (gc->items == NULL) {
    gc->nslots = old_size;
    gc->items = old_items;
    return 0;
  }
  
  for (i = 0; i < old_size; i++) {
    if (old_items[i].hash != 0) {
      cgc_add_ptr(gc, 
        old_items[i].ptr,   old_items[i].size, 
        old_items[i].flags, old_items[i].dtor);
    }
  }
  
  free(old_items);
  
  return 1;
}

static int cgc_resize_more(cgc_t *gc) {
  size_t new_size = cgc_ideal_size(gc, gc->nitems);  
  size_t old_size = gc->nslots;
  return (new_size > old_size) ? cgc_rehash(gc, new_size) : 1;
}

static int cgc_resize_less(cgc_t *gc) {
  size_t new_size = cgc_ideal_size(gc, gc->nitems);  
  size_t old_size = gc->nslots;
  return (new_size < old_size) ? cgc_rehash(gc, new_size) : 1;
}

static void cgc_mark_ptr(cgc_t *gc, void *ptr) {

  size_t i, j, h, k;
  
  if ((uintptr_t)ptr < gc->minptr 
  ||  (uintptr_t)ptr > gc->maxptr) { return; }
  
  i = cgc_hash(ptr) % gc->nslots; j = 0;
  
  while (1) {
    h = gc->items[i].hash;
    if (h == 0 || j > cgc_probe(gc, i, h)) { return; }
    if (ptr == gc->items[i].ptr) {
      if (gc->items[i].flags & TGC_MARK) { return; }
      gc->items[i].flags |= TGC_MARK;
      if (gc->items[i].flags & TGC_LEAF) { return; }
      for (k = 0; k < gc->items[i].size/sizeof(void*); k++) {
        cgc_mark_ptr(gc, ((void**)gc->items[i].ptr)[k]);
      }
      return;
    }
    i = (i+1) % gc->nslots; j++;
  }
  
}

static void cgc_mark_stack(cgc_t *gc) {
  
  void *stk, *bot, *top, *p;
  bot = gc->bottom; top = &stk;
  
  if (bot == top) { return; }
  
  if (bot < top) {
    for (p = top; p >= bot; p = ((char*)p) - sizeof(void*)) {
      cgc_mark_ptr(gc, *((void**)p));
    }
  }
  
  if (bot > top) {
    for (p = top; p <= bot; p = ((char*)p) + sizeof(void*)) {
      cgc_mark_ptr(gc, *((void**)p));
    }
  }
  
}

static void cgc_mark(cgc_t *gc) {
  
  size_t i, k;
  jmp_buf env;
  void (*volatile mark_stack)(cgc_t*) = cgc_mark_stack;
  
  if (gc->nitems == 0) { return; }
  
  for (i = 0; i < gc->nslots; i++) {
    if (gc->items[i].hash ==        0) { continue; }
    if (gc->items[i].flags & TGC_MARK) { continue; }
    if (gc->items[i].flags & TGC_ROOT) {
      gc->items[i].flags |= TGC_MARK;
      if (gc->items[i].flags & TGC_LEAF) { continue; }
      for (k = 0; k < gc->items[i].size/sizeof(void*); k++) {
        cgc_mark_ptr(gc, ((void**)gc->items[i].ptr)[k]);
      }
      continue;
    }
  }
  
  memset(&env, 0, sizeof(jmp_buf));
  setjmp(env);
  mark_stack(gc);

}

void cgc_sweep(cgc_t *gc) {
  
  size_t i, j, k, nj, nh;
  
  if (gc->nitems == 0) { return; }
  
  gc->nfrees = 0;
  for (i = 0; i < gc->nslots; i++) {
    if (gc->items[i].hash ==        0) { continue; }
    if (gc->items[i].flags & TGC_MARK) { continue; }
    if (gc->items[i].flags & TGC_ROOT) { continue; }
    gc->nfrees++;
  }

  gc->frees = realloc(gc->frees, sizeof(cgc_ptr_t) * gc->nfrees);
  if (gc->frees == NULL) { return; }
  
  i = 0; k = 0;
  while (i < gc->nslots) {
    if (gc->items[i].hash ==        0) { i++; continue; }
    if (gc->items[i].flags & TGC_MARK) { i++; continue; }
    if (gc->items[i].flags & TGC_ROOT) { i++; continue; }
    
    gc->frees[k] = gc->items[i]; k++;
    memset(&gc->items[i], 0, sizeof(cgc_ptr_t));
    
    j = i;
    while (1) { 
      nj = (j+1) % gc->nslots;
      nh = gc->items[nj].hash;
      if (nh != 0 && cgc_probe(gc, nj, nh) > 0) {
        memcpy(&gc->items[ j], &gc->items[nj], sizeof(cgc_ptr_t));
        memset(&gc->items[nj],              0, sizeof(cgc_ptr_t));
        j = nj;
      } else {
        break;
      }  
    }
    gc->nitems--;
  }
  
  for (i = 0; i < gc->nslots; i++) {
    if (gc->items[i].hash == 0) { continue; }
    if (gc->items[i].flags & TGC_MARK) {
      gc->items[i].flags &= ~TGC_MARK;
    }
  }
  
  cgc_resize_less(gc);
  
  gc->mitems = gc->nitems + (size_t)(gc->nitems * gc->sweepfactor) + 1;
  
  for (i = 0; i < gc->nfrees; i++) {
    if (gc->frees[i].ptr) {
      if (gc->frees[i].dtor) { gc->frees[i].dtor(gc->frees[i].ptr); }
      free(gc->frees[i].ptr);
    }
  }
  
  free(gc->frees);
  gc->frees = NULL;
  gc->nfrees = 0;
  
}

void cgc_start(cgc_t *gc, void *stk) {
  gc->bottom = stk;
  gc->paused = 0;
  gc->nitems = 0;
  gc->nslots = 0;
  gc->mitems = 0;
  gc->nfrees = 0;
  gc->maxptr = 0;
  gc->items = NULL;
  gc->frees = NULL;
  gc->minptr = UINTPTR_MAX;
  gc->loadfactor = 0.9;
  gc->sweepfactor = 0.5;
}

void cgc_stop(cgc_t *gc) {
  cgc_sweep(gc);
  free(gc->items);
  free(gc->frees);
}

void cgc_pause(cgc_t *gc) {
  gc->paused = 1;
}

void cgc_resume(cgc_t *gc) {
  gc->paused = 0;
}

void cgc_run(cgc_t *gc) {
  cgc_mark(gc);
  cgc_sweep(gc);
}

static void *cgc_add(
  cgc_t *gc, void *ptr, size_t size, 
  int flags, void(*dtor)(void*)) {

  gc->nitems++;
  gc->maxptr = ((uintptr_t)ptr) + size > gc->maxptr ? 
    ((uintptr_t)ptr) + size : gc->maxptr; 
  gc->minptr = ((uintptr_t)ptr)        < gc->minptr ? 
    ((uintptr_t)ptr)        : gc->minptr;

  if (cgc_resize_more(gc)) {
    cgc_add_ptr(gc, ptr, size, flags, dtor);
    if (!gc->paused && gc->nitems > gc->mitems) {
      cgc_run(gc);
    }
    return ptr;
  } else {
    gc->nitems--;
    free(ptr);
    return NULL;
  }
}

static void cgc_rem(cgc_t *gc, void *ptr) {
  cgc_rem_ptr(gc, ptr);
  cgc_resize_less(gc);
  gc->mitems = gc->nitems + gc->nitems / 2 + 1;
}

void *cgc_alloc(cgc_t *gc, size_t size) {
  return cgc_alloc_opt(gc, size, 0, NULL);
}

void *cgc_calloc(cgc_t *gc, size_t num, size_t size) {
  return cgc_calloc_opt(gc, num, size, 0, NULL);
}

void *cgc_realloc(cgc_t *gc, void *ptr, size_t size) {
  
  cgc_ptr_t *p;
  void *qtr = realloc(ptr, size);
  
  if (qtr == NULL) {
    cgc_rem(gc, ptr);
    return qtr;
  }

  if (ptr == NULL) {
    cgc_add(gc, qtr, size, 0, NULL);
    return qtr;
  }

  p  = cgc_get_ptr(gc, ptr);

  if (p && qtr == ptr) {
    p->size = size;
    return qtr;
  }

  if (p && qtr != ptr) {
    int flags = p->flags;
    void(*dtor)(void*) = p->dtor;
    cgc_rem(gc, ptr);
    cgc_add(gc, qtr, size, flags, dtor);
    return qtr;
  }

  return NULL;
}

void cgc_free(cgc_t *gc, void *ptr) {
  cgc_ptr_t *p  = cgc_get_ptr(gc, ptr);
  if (p) {
    if (p->dtor) {
      p->dtor(ptr);
    }
    free(ptr);
    cgc_rem(gc, ptr);
  }
}

void *cgc_alloc_opt(cgc_t *gc, size_t size, int flags, void(*dtor)(void*)) {
  void *ptr = malloc(size);
  if (ptr != NULL) {
    ptr = cgc_add(gc, ptr, size, flags, dtor);
  }
  return ptr;
}

void *cgc_calloc_opt(
  cgc_t *gc, size_t num, size_t size, 
  int flags, void(*dtor)(void*)) {
  void *ptr = calloc(num, size);
  if (ptr != NULL) {
    ptr = cgc_add(gc, ptr, num * size, flags, dtor);
  }
  return ptr;
}

void cgc_set_dtor(cgc_t *gc, void *ptr, void(*dtor)(void*)) {
  cgc_ptr_t *p  = cgc_get_ptr(gc, ptr);
  if (p) { p->dtor = dtor; }
}

void cgc_set_flags(cgc_t *gc, void *ptr, int flags) {
  cgc_ptr_t *p  = cgc_get_ptr(gc, ptr);
  if (p) { p->flags = flags; }
}

int cgc_get_flags(cgc_t *gc, void *ptr) {
  cgc_ptr_t *p  = cgc_get_ptr(gc, ptr);
  if (p) { return p->flags; }
  return 0;
}

void(*cgc_get_dtor(cgc_t *gc, void *ptr))(void*) {
  cgc_ptr_t *p  = cgc_get_ptr(gc, ptr);
  if (p) { return p->dtor; }
  return NULL;
}

size_t cgc_get_size(cgc_t *gc, void *ptr) {
  cgc_ptr_t *p  = cgc_get_ptr(gc, ptr);
  if (p) { return p->size; }
  return 0;
}
